"use client";
import {Select,SelectContent,SelectItem,SelectTrigger,SelectValue} from "@/components/ui/select";
export function Choice({value,onChange,items,label}:{value:string;onChange:(s:string)=>void;items:Record<string,string>;label:string}){return <Select value={value} onValueChange={onChange}><SelectTrigger aria-label={label} className="choice"><SelectValue/></SelectTrigger><SelectContent>{Object.entries(items).map(([key,text])=><SelectItem key={key} value={key}>{text}</SelectItem>)}</SelectContent></Select>}
