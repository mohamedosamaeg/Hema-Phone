export type Product={id:string;name_ar:string;name_en:string;description_ar:string;description_en:string;category:string;image:string;price:number|null;stock:number;visible:number;demo:number;revision:number;updated_at:string};
export type Settings={delivery:number;shipping:number;area:string;address:string;revision:number};
export type Category={id:string;name_ar:string;name_en:string;position:number;revision:number};
export type Order={seq:number;id:string;name:string;phone:string;address:string;method:string;notes:string;subtotal:number;shipping:number;total:number;status:string;created_at:string;revision:number;items?:{name:string;quantity:number;unit_price:number}[]};
export const defaultCategories:Category[]=[
 {id:"watches",name_ar:"ساعات ذكية",name_en:"Watches",position:10,revision:1},
 {id:"audio",name_ar:"سماعات",name_en:"Audio",position:20,revision:1},
 {id:"charging",name_ar:"شواحن وكابلات",name_en:"Charging",position:30,revision:1},
 {id:"accessories",name_ar:"إكسسوارات",name_en:"Accessories",position:40,revision:1}
];
export const statusNames:Record<string,[string,string]>={new:["جديد","New"],confirmed:["مؤكد","Confirmed"],preparing:["قيد التجهيز","Preparing"],dispatched:["خرج للتوصيل","Dispatched"],completed:["مكتمل","Completed"],cancelled:["ملغي","Cancelled"]};
