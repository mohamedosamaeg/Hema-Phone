import { z } from "zod";
export const productSchema=z.object({
 name_ar:z.string().trim().min(2).max(150),name_en:z.string().trim().min(2).max(150),
 description_ar:z.string().max(2000),description_en:z.string().max(2000),
 category:z.string().trim().min(2).max(50).regex(/^[a-z0-9-]+$/),image:z.string().max(200).refine(s=>!s||/^\/(assets\/[\w.-]+|api\/images\/[a-f0-9-]+)$/.test(s)),
 price:z.number().int().min(0).max(100000000).nullable(),stock:z.number().int().min(0).max(100000),
 visible:z.boolean(),demo:z.boolean(),revision:z.number().int().min(1).optional()
}).refine(p=>p.demo||(p.price!==null&&p.price>0),{message:"أدخل سعرًا صحيحًا للمنتج المتاح للبيع"});
export const categorySchema=z.object({id:z.string().trim().min(2).max(50).regex(/^[a-z0-9-]+$/),name_ar:z.string().trim().min(2).max(80),name_en:z.string().trim().min(2).max(80),position:z.number().int().min(0).max(100000),revision:z.number().int().min(1).optional()});
export const orderSchema=z.object({
 key:z.string().uuid(),name:z.string().trim().min(2).max(100),
 phone:z.string().regex(/^01[0125][0-9]{8}$/),method:z.enum(["pickup","delivery"]),
 address:z.string().trim().max(500),notes:z.string().max(500).default(""),
 items:z.array(z.object({id:z.string().min(1).max(80),quantity:z.number().int().min(1).max(20)})).min(1).max(30)
}).refine(o=>o.method!=="delivery"||o.address.length>=10,{message:"أدخل عنوان التوصيل كاملًا"});
export function transitionAllowed(from:string,to:string){
 return ({new:["confirmed","cancelled"],confirmed:["preparing","cancelled"],preparing:["dispatched","completed","cancelled"],dispatched:["completed"],completed:[],cancelled:[]} as Record<string,string[]>)[from]?.includes(to)??false;
}
