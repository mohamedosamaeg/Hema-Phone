import { env } from "cloudflare:workers";
export function db(){if(!env.DB)throw new Error("Database unavailable");return env.DB}
export function bucket(){if(!env.BUCKET)throw new Error("Image storage unavailable");return env.BUCKET}

