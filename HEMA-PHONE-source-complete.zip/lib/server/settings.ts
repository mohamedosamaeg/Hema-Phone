import {db} from "./db";
export async function settings(){return await db().prepare("SELECT delivery,shipping,area,address,revision FROM settings WHERE id=1").first()||{delivery:0,shipping:0,area:"",address:"",revision:1}}

