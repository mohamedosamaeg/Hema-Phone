import {db} from "./db";
import {defaultCategories} from "@/lib/types";

export async function ensureCategories(){
 const database=db();
 await database.prepare("CREATE TABLE IF NOT EXISTS categories (id text PRIMARY KEY NOT NULL, name_ar text NOT NULL, name_en text NOT NULL, position integer NOT NULL DEFAULT 0, revision integer NOT NULL DEFAULT 1)").run();
 await database.batch(defaultCategories.map(c=>database.prepare("INSERT OR IGNORE INTO categories(id,name_ar,name_en,position,revision) VALUES(?,?,?,?,1)").bind(c.id,c.name_ar,c.name_en,c.position)));
}
export async function categoryList(){await ensureCategories();return (await db().prepare("SELECT * FROM categories ORDER BY position ASC, name_ar ASC").all()).results}
export async function categoryExists(id:string){await ensureCategories();return !!(await db().prepare("SELECT id FROM categories WHERE id=?").bind(id).first())}
