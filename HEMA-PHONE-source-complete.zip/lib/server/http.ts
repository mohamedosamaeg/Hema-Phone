export class HttpError extends Error {constructor(public status:number,message:string){super(message)}}
export function json(data:unknown,status=200){return Response.json(data,{status,headers:{"Cache-Control":"no-store","X-Content-Type-Options":"nosniff"}})}
export function sameOrigin(request:Request){
 const origin=request.headers.get("origin");
 if(origin!==new URL(request.url).origin)throw new HttpError(403,"Invalid request origin");
}
export async function body(request:Request,max=32000){
 if(!(request.headers.get("content-type")||"").startsWith("application/json"))throw new HttpError(415,"JSON required");
 if(Number(request.headers.get("content-length")||0)>max)throw new HttpError(413,"Request too large");
 const text=await request.text();if(new TextEncoder().encode(text).length>max)throw new HttpError(413,"Request too large");
 try{return JSON.parse(text)}catch{throw new HttpError(400,"Invalid JSON")}
}
export async function handle(work:()=>Promise<Response>){
 try{return await work()}catch(error){
 if(error instanceof HttpError)return json({error:error.message},error.status);
 console.error("Store request failed",error instanceof Error?error.message:"unknown");
 return json({error:"الخدمة غير متاحة مؤقتًا، حاول مرة أخرى / Temporarily unavailable"},503);
 }
}

