import { sqliteTable, text, integer, index, check } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";
export const products = sqliteTable("products", {
 id:text("id").primaryKey(), name_ar:text("name_ar").notNull(), name_en:text("name_en").notNull(),
 description_ar:text("description_ar").notNull().default(""), description_en:text("description_en").notNull().default(""),
 category:text("category").notNull(), image:text("image").notNull().default(""), price:integer("price"),
 stock:integer("stock").notNull().default(0), visible:integer("visible").notNull().default(1),
 demo:integer("demo").notNull().default(1), revision:integer("revision").notNull().default(1),
 updated_at:text("updated_at").notNull()
},t=>[check("stock_nonnegative",sql`${t.stock} >= 0`),check("price_nonnegative",sql`${t.price} is null or ${t.price} >= 0`)]);
export const orders = sqliteTable("orders", {
 seq:integer("seq").primaryKey({autoIncrement:true}), id:text("id").notNull().unique(),
 request_key:text("request_key").notNull().unique(), request_hash:text("request_hash").notNull(),
 name:text("name").notNull(), phone:text("phone").notNull(), address:text("address").notNull(),
 method:text("method").notNull(), notes:text("notes").notNull().default(""),
 subtotal:integer("subtotal").notNull(), shipping:integer("shipping").notNull(), total:integer("total").notNull(),
 status:text("status").notNull().default("new"), created_at:text("created_at").notNull(), revision:integer("revision").notNull().default(1)
},t=>[index("orders_status_seq").on(t.status,t.seq)]);
export const orderItems = sqliteTable("order_items",{
 id:integer("id").primaryKey({autoIncrement:true}), order_id:text("order_id").notNull().references(()=>orders.id),
 product_id:text("product_id").notNull().references(()=>products.id), name:text("name").notNull(),
 quantity:integer("quantity").notNull(), unit_price:integer("unit_price").notNull()
},t=>[index("items_order").on(t.order_id),check("quantity_positive",sql`${t.quantity} > 0`)]);
export const settings = sqliteTable("settings",{id:integer("id").primaryKey(),delivery:integer("delivery").notNull().default(0),shipping:integer("shipping").notNull().default(0),area:text("area").notNull().default(""),address:text("address").notNull().default(""),revision:integer("revision").notNull().default(1)});
export const categories = sqliteTable("categories",{id:text("id").primaryKey(),name_ar:text("name_ar").notNull(),name_en:text("name_en").notNull(),position:integer("position").notNull().default(0),revision:integer("revision").notNull().default(1)});
export const admins = sqliteTable("admins",{slot:integer("slot").primaryKey(),user_id:text("user_id").notNull().unique()});
export const rateLimits = sqliteTable("rate_limits",{key:text("key").primaryKey(),count:integer("count").notNull(),expires:integer("expires").notNull()});
