CREATE TABLE `categories` (
	`id` text PRIMARY KEY NOT NULL,
	`name_ar` text NOT NULL,
	`name_en` text NOT NULL,
	`position` integer DEFAULT 0 NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
INSERT OR IGNORE INTO `categories` (`id`,`name_ar`,`name_en`,`position`,`revision`) VALUES
('watches','ساعات ذكية','Watches',10,1),
('audio','سماعات','Audio',20,1),
('charging','شواحن وكابلات','Charging',30,1),
('accessories','إكسسوارات','Accessories',40,1);
