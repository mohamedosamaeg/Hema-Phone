CREATE TABLE `admin_accounts` (`id` integer PRIMARY KEY NOT NULL,`username` text NOT NULL UNIQUE,`email` text NOT NULL,`phone` text NOT NULL,`password_hash` text NOT NULL,`salt` text NOT NULL,`updated_at` text NOT NULL);
--> statement-breakpoint
CREATE TABLE `admin_sessions` (`token_hash` text PRIMARY KEY NOT NULL,`account_id` integer NOT NULL,`expires_at` integer NOT NULL,FOREIGN KEY (`account_id`) REFERENCES `admin_accounts`(`id`) ON DELETE CASCADE);
--> statement-breakpoint
CREATE INDEX `admin_sessions_expiry` ON `admin_sessions` (`expires_at`);
