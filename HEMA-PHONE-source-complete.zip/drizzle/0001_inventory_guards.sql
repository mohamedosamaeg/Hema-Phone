CREATE INDEX IF NOT EXISTS `products_visible_updated` ON `products` (`visible`,`updated_at`);
