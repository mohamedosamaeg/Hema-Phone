import {settings} from "@/lib/server/settings";import {handle,json} from "@/lib/server/http";
export async function GET(){return handle(async()=>json(await settings()))}

