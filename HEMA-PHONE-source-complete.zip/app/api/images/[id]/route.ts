import {bucket} from "@/lib/server/db";import {handle,HttpError} from "@/lib/server/http";
export async function GET(request:Request,context:{params:Promise<{id:string}>}){return handle(async()=>{const {id}=await context.params;if(!/^[a-f0-9-]{36}$/.test(id))throw new HttpError(404,"Not found");const file=await bucket().get(id);if(!file)throw new HttpError(404,"Not found");return new Response(file.body,{headers:{"Content-Type":file.httpMetadata?.contentType||"application/octet-stream","Cache-Control":"public,max-age=86400","X-Content-Type-Options":"nosniff"}})})}

