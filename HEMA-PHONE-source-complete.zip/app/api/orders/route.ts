import {db} from "@/lib/server/db";
import {settings} from "@/lib/server/settings";
import {body,handle,json,sameOrigin,HttpError} from "@/lib/server/http";
import {orderSchema} from "@/lib/validation";
import type {Product} from "@/lib/types";
async function digest(text:string){return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(text)))).map(b=>b.toString(16).padStart(2,"0")).join("")}
export async function POST(request:Request){return handle(async()=>{
 sameOrigin(request);
 const parsed=orderSchema.safeParse(await body(request));
 if(!parsed.success)throw new HttpError(400,"راجع الاسم ورقم الموبايل والعنوان / Check your details");
 const input=parsed.data;
 if(new Set(input.items.map(i=>i.id)).size!==input.items.length)throw new HttpError(400,"Duplicate items");
 input.items.sort((a,b)=>a.id.localeCompare(b.id));
 const hash=await digest(JSON.stringify(input));
 const previous=await db().prepare("SELECT id,total,request_hash FROM orders WHERE request_key=?").bind(input.key).first<{id:string;total:number;request_hash:string}>();
 if(previous){if(previous.request_hash!==hash)throw new HttpError(409,"استخدم محاولة جديدة للطلب");return json({id:previous.id,total:previous.total})}
 const slot=Math.floor(Date.now()/3600000);
 const ip=request.headers.get("cf-connecting-ip")||"unknown";
 const rateKey=await digest(ip+":"+slot);
 await db().prepare("INSERT INTO rate_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1").bind(rateKey,(slot+1)*3600000).run();
 const rate=await db().prepare("SELECT count FROM rate_limits WHERE key=?").bind(rateKey).first<{count:number}>();
 if((rate?.count||0)>20)throw new HttpError(429,"محاولات كثيرة، حاول لاحقًا / Try later");
 await db().prepare("DELETE FROM rate_limits WHERE expires<?").bind(Date.now()-86400000).run();
 const config=await settings() as {delivery:number;shipping:number};
 if(input.method==="delivery"&&!config.delivery)throw new HttpError(400,"التوصيل غير متاح الآن / Delivery is unavailable");
 const lines: {product:Product;quantity:number}[]=[];
 for(const item of input.items){
  const product=await db().prepare("SELECT * FROM products WHERE id=?").bind(item.id).first<Product>();
  if(!product||!product.visible||product.demo||product.price===null||product.stock<item.quantity)throw new HttpError(409,"منتج غير متاح أو كمية غير كافية / Product unavailable");
  lines.push({product,quantity:item.quantity});
 }
 const subtotal=lines.reduce((sum,l)=>sum+(l.product.price||0)*l.quantity,0),shipping=input.method==="delivery"?config.shipping:0,total=subtotal+shipping;
 const id="HP-"+crypto.randomUUID(),date=new Date().toISOString();
 const statements=[
 db().prepare("INSERT OR IGNORE INTO settings(id) VALUES(1)"),
 ...lines.map(l=>db().prepare("UPDATE products SET stock=stock-?,revision=revision+1 WHERE id=? AND stock>=?").bind(l.quantity,l.product.id,l.quantity)),
 db().prepare("INSERT INTO orders(id,request_key,request_hash,name,phone,address,method,notes,subtotal,shipping,total,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)").bind(id,input.key,hash,input.name,input.phone,input.method==="delivery"?input.address:"استلام من المحل",input.method,input.notes,subtotal,shipping,total,date),
 ...lines.map(l=>db().prepare("INSERT INTO order_items(order_id,product_id,name,quantity,unit_price) VALUES(?,?,?,?,?)").bind(id,l.product.id,l.product.name_ar+" / "+l.product.name_en,l.quantity,l.product.price))
 ];
 try{await db().batch(statements)}catch{
  const retry=await db().prepare("SELECT id,total,request_hash FROM orders WHERE request_key=?").bind(input.key).first<{id:string;total:number;request_hash:string}>();
  if(retry&&retry.request_hash===hash)return json({id:retry.id,total:retry.total});
  throw new HttpError(409,"السعر أو المخزون أو الشحن اتغير؛ حدّث السلة / Refresh your cart");
 }
 return json({id,total},201);
})}
