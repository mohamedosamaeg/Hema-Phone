import {categoryList} from "@/lib/server/categories";import {handle,json} from "@/lib/server/http";
export async function GET(){return handle(async()=>json({categories:await categoryList()}))}
