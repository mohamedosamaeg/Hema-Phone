import {redirect} from "next/navigation";import {admin} from "@/lib/server/auth";import AdminPanel from "@/components/store/AdminPanel";
export const dynamic="force-dynamic";export default async function Page(){try{const owner=await admin();return <AdminPanel email={owner.email}/>}catch{redirect("/admin/login")}}
