import type { Metadata } from "next";
import "./globals.css";
import "./brand.css";
import "./footer.css";
import "./catalog-label.css";
import "./private-admin-link.css";

export const metadata: Metadata = {
  title: "HEMA PHONE | فور يور فون",
  description: "ساعات وسماعات وإكسسوارات HEMA PHONE",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
